import pygame, sys,random
from pygame.locals import *
FPS =15 # frames per second setting
BLACK     = (  0,   0,   0)
GREEN     = (  0, 255,   0)
WHITE	= (255, 255, 255)
MAROON	=(128,0,0)
K_LEFT = 'left'
K_RIGHT = 'right'
K_DOWN ='down'
def main():
	global fpsClock, DISPLAYSURF, BASICFONT,petImg,banImg
	pygame.init()
	fpsClock = pygame.time.Clock()
	DISPLAYSURF = pygame.display.set_mode((720, 600), 0, 32)
	DISPLAYSURF.fill(WHITE)
	pygame.display.set_caption('        MARSUPILAMI      ')
	BASICFONT = pygame.font.Font('freesansbold.ttf',35)
	pressKeySurf = BASICFONT.render('PRESS ANY KEY TO PLAY GAME.', True,GREEN)
	pressKeyRect = pressKeySurf.get_rect()
	pressKeyRect.topleft= (1,300)
	DISPLAYSURF.blit(pressKeySurf, pressKeyRect)
	while True:

        	runGame()


		
def runGame():
	petImg = pygame.image.load('marsu.jpeg')
	petx = 500
	pety = 410
	banImg =pygame.image.load('banana.jpeg')
	banx =random.randint(5,550)
	bany =15
	score=0
	bmbImg =pygame.image.load('bmb.jpg')
	bmbx =random.randint(5,550)
	bmby=10
	while True:
		DISPLAYSURF.fill(WHITE)
		bany +=5
		if(bany==410):
                	banImg=pygame.image.load('banana.jpeg')
                        banx =random.randint(5,550)
                        bany =15
		bmby +=10
		if(bmby==400):
			bmbImg=pygame.image.load('bmb.jpg')
			bmbx =random.randint(20,650)
			bmby =30
		DISPLAYSURF.blit(banImg, (banx,bany))
		DISPLAYSURF.blit(petImg, (petx,pety))
		DISPLAYSURF.blit(bmbImg, (bmbx,bmby))
		for event in pygame.event.get():
		#	DISPLAYSURF.fill(WHITE)
			if event.type == KEYDOWN:    
				#if( event.key ==pygame.K_DOWN):	
				#	bany +=5
                        	#	if(bany==410):
                                #		banImg=pygame.image.load('banana.jpeg')
                                #		banx =random.randint(5,550)
                                #		bany =15	
						
				if( event.key ==pygame.K_LEFT):
					petx -= 15
				elif (event.key ==pygame.K_RIGHT):
                			petx += 15
			#	if(bany==390 and banx+35>petx and banx+170<petx+300):
                         #              score += 5
                         
			#	Score(score)
				#DISPLAYSURF.fill(WHITE)
				DISPLAYSURF.blit(banImg, (banx,bany))
				DISPLAYSURF.blit(petImg, (petx,pety))
				DISPLAYSURF.blit(bmbImg, (bmbx,bmby))
				#DISPLAYSURF.blit(bmbImg, (bmbx,bmby))
				#if(bany==390 and banx+35>petx and banx+170<petx+300):
				#	score += 5
				#Score(score)
				#DISPLAYSURF.blit(scoreSurf,scoreRect)
        		if event.type == QUIT:
				pygame.quit()
				sys.exit()
		if(bany==390 and banx+35>petx and banx+170<petx+300):
                	score += 5

		Score(score)
		if(bmby==360 and bmbx+35>petx and bmbx+170<petx+300):
			#pygame.time.wait(500)
			DISPLAYSURF.fill(GREEN)
			goImg=pygame.image.load('go.jpg')
                        gox =250
                        goy =200
        	        DISPLAYSURF.blit(goImg, (gox,goy))
			pygame.display.update()
			pygame.time.wait(500)
			pygame.quit()
			sys.exit()	
		pygame.display.update()
		fpsClock.tick(FPS)
def Score(point):
    scoreSurf = BASICFONT.render('Score: %s' % (point), True, MAROON)
    scoreRect = scoreSurf.get_rect()
    scoreRect.topleft = (500,20)
    DISPLAYSURF.blit(scoreSurf, scoreRect)
if __name__ == '__main__':

    main()
